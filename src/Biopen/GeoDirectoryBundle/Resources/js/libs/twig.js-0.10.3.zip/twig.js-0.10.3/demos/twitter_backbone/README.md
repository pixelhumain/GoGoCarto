# Twig.Twitter

This is a demonstration of using Twig to create a application for viewing a user's Twitter stream. It's fairly simple as such things go, but it demonstrates how to use twig with Backbone.js Views.

To get started, you should look through the views in js/views to get an idea of how the templates are setup.

